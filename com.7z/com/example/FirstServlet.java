package com.example;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class FirstServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		RequestDispatcher dispatcher=null;
		String param=request.getParameter("go");
		if(param==null)
		{	
		throw new ServletException("No parameters in my controller");
		}	
		else if(param.equals("weather"))
		{
			dispatcher=request.getRequestDispatcher("/weather");
			
		}else if(param.equals("map"))
		{
			dispatcher=request.getRequestDispatcher("/map");
		}else throw new ServletException("Invalid parameter");
			if (dispatcher!=null){
				dispatcher.forward(request, response);
				
			}else throw new ServletException("NULL ERROR!!!");
		
		
		
	}
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
	}
		
		
		
		
}
