package com.naima.fronface;
import java.util.Date;
 
public class User {
   String username, password;
   Date registeredon;
 
   public String getUserName(){
		return  username;
		
	}     
 
	public String getPassword(){
		return  password;
		
	}   

	public void setUserName(String s){
		username=s;
		
	}     
 
	public void setPassword(String p){
		password=p;
		
   
	}	
}
