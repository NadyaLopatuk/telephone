package com.naima.phonebase;

import java.sql.*;
import java.util.*;
import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.naima.dao.UserConnection;

public class WorkRegion extends HttpServlet{
	private UserConnection dao;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
           
		
		   
	}			
	
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String forward="";
        String action = request.getParameter("action");
		PrintWriter pw=response.getWriter();
        if (action.equalsIgnoreCase("delete")){
                pw.println("you case delete");
        } else if (action.equalsIgnoreCase("edit")){
            pw.println("you case edit");
        } else if (action.equalsIgnoreCase("listRegion")){
            forward = "/base/regedit.jsp";
           // request.setAttribute("regions", dao.selRegions());
			pw.println(forward+" "+action);
        } else {
            pw.println("you case update");
        }
        //RequestDispatcher view = request.getRequestDispatcher(forward);
        //view.forward(request, response);
		   
		   	      	 
 
    }
	
}
	


