package com.naima.fronface;
public class Markers{
 String markerName;
 int markerID;
 
 public String getMarkerName(){
		return  markerName;
		
	}     
 
	public int getMarkerID(){
		return  markerID;
		
	}   

	public void setMarkerName(String s){
		markerName=s;
		
	}     
 
	public void setMarkerID(int p){
		markerID=p;
		


}
}