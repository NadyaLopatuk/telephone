package com.naima.fronface;
public class Towns{
 String townName;
 String regionName;
 int townID;
 
 public String getTownName(){
		return  townName;
		
	}     
 public String getRegionName(){
		return  regionName;
		
	} 
	public int getTownID(){
		return  townID;
		
	}   

	public void setTownName(String s){
		townName=s;
		
	}     
 
 public void setRegionName(String s){
		regionName=s;
		
	} 
	public void setTownID(int p){
		townID=p;
		


}
}