package com.naima.fronface;
public class Streets{
 String streetName;
 int streetID;
 
 public String getStreetName(){
		return  streetName;
		
	}     
 
	public int getStreetID(){
		return  streetID;
		
	}   

	public void setStreetName(String s){
		streetName=s;
		
	}     
 
	public void setStreetID(int p){
		streetID=p;
		


}
}