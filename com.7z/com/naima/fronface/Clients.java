package com.naima.fronface;
public class Clients{
 String clientPhone, marker, clientFamily, clientName, clientSubname, clientPass,clientEmail, regionName, townName, streetName;
 int  clientID,houseNum, flatNum;
 //пары геттер-сеттер
 //телефон клиента
 public String getClientPhone(){
		return  clientPhone;
		
	}     
public void setClientPhone(String s){
		clientPhone=s;
		
	}    
//параметр связи 	
	   
public String getMarker(){
		return  marker;
		
	}   
public void setMarker(String s){
		marker=s;
		


}
//имя клиента 
 
 public String getClientName(){
		return  clientName;
		
	} 

public void setClientName(String s){
		clientName=s;
		
	} 
    
 //фамилия клиента
	public String getClientFamily(){
		return  clientFamily;
		
	}

 public void setClientFamily(String s){
		clientFamily=s;
		
	}
	
//отчетво
	public String getClientSubname(){
		return  clientSubname;
		
	}
public void setClientSubname(String s){
		clientSubname=s;
		
	} 
	
//номер пасспорта	
	public String getClientPass(){
		return  clientPass;
		
	} 

public void setClientPass(String s){
		clientPass=s;
		
	} 	
	
	
//электронная почта		
	public String getClientEmail(){
		return  clientEmail;
		
	} 
	
public void setClientEmail(String s){
		clientEmail=s;
		
	}	
	
//название города клиента	
	
	public String getTownName(){
		return  townName;
		
	} 
	
public void setTownName(String s){
		townName=s;
	}	
	
	
//наименование региона	
	
	
	public String getRegionName(){
		return  regionName;
		
	} 
	
public void setRegionName(String s){
		regionName=s;
	}	
	
	
//название улицы	
	
	public String getStreetName(){
		return  streetName;
		
	} 
	
	public void setStreetName(String s){
		streetName=s;
	}
	
	
//номер дома
public int getHouseNum(){
		return  houseNum;
		
	} 
public void setHouseNum(int p){
		houseNum=p;
	}	

	
//номер квартиры	
	 public int getFlatNum(){
		return  flatNum;
		
	} 
	
	public void setFlatNum(int p){
		flatNum=p;
	}	
	
//порядковый номер в базе	
	public int getClientID(){
		return   clientID;
		
	}     
 
  	
	public void setClientID(int p){
		clientID=p;
	}
	
	
}