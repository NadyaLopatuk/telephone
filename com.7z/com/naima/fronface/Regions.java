package com.naima.fronface;
public class Regions{
 String regionName;
 int regionID;
 
 public String getRegionName(){
		return  regionName;
		
	}     
 
	public int getRegionID(){
		return  regionID;
		
	}   

	public void setRegionName(String s){
		regionName=s;
		
	}     
 
	public void setRegionID(int p){
		regionID=p;
		


}
}