package com.naima.util;
import java.sql.Connection;
import java.sql.DriverManager;
import com.naima.fronface.User;

public class DBase {
      static final String url="jdbc:postgresql://127.0.0.1:5432/phoneDirectory";
	  public static Connection getConnection(String user, String password) {
         
		  try  {
             Class.forName("org.postgresql.Driver");
             Connection con = DriverManager.getConnection(url, user, password);
              return con;
          }
          catch(Exception ex) {
              System.out.println("Database.getConnection() Error -->" + ex.getMessage());
              return null;
          }
      }
 
       public static void close(Connection con) {
          try  {
              con.close();
          }
          catch(Exception ex) {
          }
      }
	  
}