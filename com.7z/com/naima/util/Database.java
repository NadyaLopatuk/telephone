package com.naima.util;
import java.sql.Connection;
import java.util.Properties;
import java.sql.DriverManager;
public class Database {
      static final String url="jdbc:postgresql://127.0.0.1:5432/phoneDirectory";
	  public static Connection getConnection() {
          try  {
              Properties connInfo = new Properties();

				connInfo.put("user", "postgres");
			connInfo.put("password", "lugansk2014");
			connInfo.put("charSet", "UTF-8");
			  Class.forName("org.postgresql.Driver");
              Connection con = DriverManager.getConnection(url,connInfo);
              return con;
          }
          catch(Exception ex) {
              System.out.println("Database.getConnection() Error -->" + ex.getMessage());
              return null;
          }
      }
 
       public static void close(Connection con) {
          try  {
              con.close();
          }
          catch(Exception ex) {
          }
      }
	  
}