package com.naima.model;
import java.util.Date;
 
public class User {
   String uname, password, email;
   Date registeredon;
   public User()
   {
	   
         
          System.out.println("Constructor USER");
	   
   }
    public String getUname(){
		return uname;
		
	}
	public String getPassword(){
		return password;
		
	}
	
	public String getEmail(){
		return email;
		
	}
	
	public Date getRegisteredon(){
		 Date registeredon =  new Date();
		return registeredon;
	}
	
	public void setUname(String u){
		uname=u;
		
	}
	
	public void setPassword(String p){
		password=p;
		
	}
	
	public void setEmail(String e){
		email=e;
	}
	
	public void setRegisteredon(Date d){
		registeredon=d;
		
	}
}