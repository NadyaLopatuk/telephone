package com.naima.dao;
 
import java.sql.*;
import java.util.*;
import java.io.*;
import com.naima.fronface.Regions;
import com.naima.fronface.Towns;
import com.naima.fronface.Streets;
import com.naima.fronface.Markers;
import com.naima.fronface.Clients;
import com.naima.util.DBase;


public class UserConnection{
	
	
	private Connection connection;
	private String us;
	public UserConnection(String u, String p) {
        	 connection = DBase.getConnection(u,p);
	         us=u;
	 }

	
		
	
	
	public boolean checkUser(){
		   boolean usersuper;
	   try{
		   PreparedStatement query=connection.prepareStatement("select usesuper from pg_user where usename=?");
            query.setString(1, us);
           ResultSet result = query.executeQuery();
		    if (result.next()) {
				usersuper=result.getBoolean("usesuper");
				return usersuper;		
				
			}else return false;
		   
	   }
	   catch(SQLException e){
		      
			  System.out.println("Database.getConnection() Error -->" + e.getMessage());}
      return false;
	  }  
	
//выборка перечня регионов из базы данных	
	public List<Regions>  selRegions(){
		List<Regions> reg = new ArrayList<Regions>();
		try{
		PreparedStatement query=connection.prepareStatement("select * from region_card");
        ResultSet result = query.executeQuery();
		while (result.next()){
			Regions region=new Regions();
			region.setRegionName(result.getString("name_region"));
			region.setRegionID(result.getInt("id_region"));
			reg.add(region);
		}	
		
		}
		catch(SQLException e){
			System.out.println("Database.getConnection() Error -->" + e.getMessage());
			
		}
		
		return reg;
		
	}
	
	//выборка перечня городов из базы данных	
	public List<Towns>  selTowns(){
		List<Towns> town = new ArrayList<Towns>();
		try{
		PreparedStatement query=connection.prepareStatement("select id_town, name_town, name_region from town_card, region_card where town_card.id_region=region_card.id_region");
        ResultSet result = query.executeQuery();
		while (result.next()){
			Towns tw=new Towns();
			tw.setRegionName(result.getString("name_region"));
			tw.setTownName(result.getString("name_town"));
			tw.setTownID(result.getInt("id_town"));
			town.add(tw);
		}	
		
		}
		catch(SQLException e){
			System.out.println("Database.getConnection() Error -->" + e.getMessage());
			
		}
		
		return town;
		
	}
	
	
	//выборка перечня улиц из базы данных	
	public List<Streets>  selStreets(){
		List<Streets> street = new ArrayList<Streets>();
		try{
		PreparedStatement query=connection.prepareStatement("select * from street_cards");
        ResultSet result = query.executeQuery();
		while (result.next()){
			Streets st=new Streets();
			st.setStreetName(result.getString("name_street"));
			st.setStreetID(result.getInt("id_street"));
			street.add(st);
		}	
		
		}
		catch(SQLException e){
			System.out.println("Database.getConnection() Error -->" + e.getMessage());
			
		}
		
		return street;
		
	}
	
	
	//выборка перечня параметров связи из базы данных	
	public List<Markers>  selParams(){
		List<Markers> param = new ArrayList<Markers>();
		try{
		PreparedStatement query=connection.prepareStatement("select * from marker_phone");
        ResultSet result = query.executeQuery();
		while (result.next()){
			Markers mk=new Markers();
			mk.setMarkerName(result.getString("name_marker"));
			mk.setMarkerID(result.getInt("id_marker"));
			param.add(mk);
		}	
		
		}
		catch(SQLException e){
			System.out.println("Database.getConnection() Error -->" + e.getMessage());
			
		}
		
		return param;
		
	}
	
	
	//выборка пользователей из базы данных	
	public List<Clients>  selClients(){
		String s, s1, s2, s3;
		List<Clients> clientPhone = new ArrayList<Clients>();
		try{
		PreparedStatement query=connection.prepareStatement("select client_card.id_client, phone, name_marker, family, name, subname, passport, email, name_region, name_town, name_street,  num_house, num_plat from client_card, client_phones, marker_phone, town_card, street_cards, region_card where client_card.id_client=client_phones.id_client and client_phones.id_marker=marker_phone.id_marker and client_card.id_town=town_card.id_town and client_card.id_street=street_cards.id_street and town_card.id_region=region_card.id_region");
        ResultSet result = query.executeQuery();
		
		
		
		while (result.next()){
			Clients phclient=new Clients();
			phclient.setClientPhone(result.getString("phone"));
			phclient.setMarker(result.getString("name_marker"));
			phclient.setClientName(result.getString("name"));
			phclient.setClientFamily(result.getString("family"));
			phclient.setClientSubname(result.getString("subname"));
			phclient.setClientPass(result.getString("passport"));
			phclient.setClientEmail(result.getString("email"));
			phclient.setTownName(result.getString("name_town"));
			phclient.setRegionName(result.getString("name_region"));
			phclient.setStreetName(result.getString("name_street"));
			phclient.setHouseNum(result.getInt("num_house"));
			phclient.setFlatNum(result.getInt("num_plat"));
			phclient.setClientID(result.getInt("id_client"));
			clientPhone.add(phclient);
		}	
		
		}
		catch(SQLException ex){
			try{
						BufferedWriter write=new BufferedWriter(new FileWriter("c:\\java\\loggs.txt"));
			write.write(ex.getMessage());
			write.close();
			
			
		}
		catch(IOException e) 
		{
			e.printStackTrace();
		}
			
			
			
		}
		
			
		return clientPhone;
		
	}
	
	
	
	
//добавить новый регион

	public void addRegion(Regions reg){
		try{
				PreparedStatement query =connection.prepareStatement("insert into region_card (name_region) values (?)");
				query.setString(1, reg.getRegionName());
				query.executeUpdate();
		}
		catch (SQLException e){
			System.out.println("Database.getConnection() Error -->" + e.getMessage());
			
		}
		
	}

//удалить выбранный регион
	public void deleteRegion(String region){
		try{
			PreparedStatement query =connection.prepareStatement("delete  from region_card where region_name=?");
			query.setString(1, region);
			query.executeUpdate();
			
		}
		catch(SQLException e){
			
			System.out.println("Database.getConnection() Error -->" + e.getMessage());
		}
		
	}

//изменить регион	
	public void updateRegion(Regions region, String regName){
		try{
		PreparedStatement query =connection.prepareStatement("update region_card set name_region=? where region_name=?");
				query.setString(1, regName);
				String regN=region.getRegionName();
				query.setString(2, regN);
				query.executeUpdate();
				
		}
			catch(SQLException e){
			System.out.println("Database.getConnection() Error -->" + e.getMessage());	
			}
		
	}
	
//поиск по номеру записи в базе
	public Regions getRegionByID(String reName){
		Regions reg=new Regions();
		
		try{
			PreparedStatement query = connection.prepareStatement("select * from region_card where id_region=?");
           	int i=Integer.parseInt(reName);
			query.setInt(1, i);
            ResultSet rs = query.executeQuery();
			if (rs.next()) {
                reg.setRegionName(rs.getString("name_region"));
                reg.setRegionID(rs.getInt("id_region"));
				
				
             }
		}
		catch(SQLException e)
		{
		   System.out.println("Database.getConnection() Error -->" + e.getMessage());	
		}
		
		
		return reg;	
			
		
	}
	
	
	
	
	

}