package  com.naima.phonebase;
import java.net.URL;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class RegionReg  extends HttpServlet
{
public void init(ServletConfig conf) throws ServletException{
	
		super.init(conf);
	}

protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String usr;
		String passw;
		resp.setContentType("text/html;charset=utf-8");
        PrintWriter pw = resp.getWriter();
		pw.println("<body>едактируем регион<br>");
	
}
	
}

