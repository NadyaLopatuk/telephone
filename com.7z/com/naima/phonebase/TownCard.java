package com.naima.model;
import java.util.*;
public class TownCard{
	String townname, regionname;
    int region;
	
		public String getTownName()
		{
			return townname;
			
		}
		
		public int getTownRegion()
		{
			return region;
			
		}
		
		public void setTownRedion(int r){
			region=r;
			
		}
	
		public void setRegionName(String rs){
			regionname=rs;
			
		}
	
	    public void setTownName(String s){
			townname=s;
			
		}
}