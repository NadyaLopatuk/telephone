package com.naima.phonebase;
 
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import java.io.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.naima.fronface.User;
import com.naima.fronface.Regions;
import com.naima.dao.UserConnection;

public class BaseWork extends HttpServlet
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		pw.println("new servlet");
		
		


	}


}