package com.naima.util;
import java.net.URL;
import java.sql.*;
import java.io.*;
public class DataBase{
	static final String url="jdbc:postgresql://127.0.0.1:5432/phoneDirectory";
		
	public static Connection getConnection(){
		
		
		try{
			Class.forName ("org.postgresql.Driver");
			con = DriverManager.getConnection(url, "postgres", "lugansk2014");
			return con;
			
		}
		catch(Exception ex){
			System.out.println("ERROR: "+ex.getMessage());
			return null;
		}
		
		
	}
	
	public static void close(Connection con){
		try {
			con.close();
			
		}
		catch(Exception ex){
			
			
		}
		
		
	}
	
}