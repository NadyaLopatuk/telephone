package com.naima.dao;
import java.sql.*;
import java.util.*;
import com.naima.util.DataBase;
import com.naima.model.TownCard;

public class UserDao{
	private connection connection;
	public UserDao(){
		connection=DataBase.getConnection();
		
	}
	
	private void checkTown(TownCard town){
		try{
			PreparedStatement query=connection.prepareStatement("Select name_town fron town_cars where name_town=?");
			query.setString(1, town.getTownName());
			ResultSet rs=query.executeQuery();
			if(rs.next()){
				updateTownCard(town);
				
			}else
			{
				addTown(town);
				
			}
			
		}catch(Exception ex){
			System.out.println("ERROR in checkTown: "+ex.getMessage());
			
		}
		
	}
	
	public void deleteTown(String townName){
		try{
			Preparesatetment query=connection.prepareSatement("delete from town_card where name_town=?");
			query.setString(1,townName);
			query.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
	}
	
	
	public void addTown(TownCard town){
		try{
			PreparedStatement query = connection.prepareStatment("inset into town_card (name_town) values (?)");
			query.setString(1,town.getTownName());
			query.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
			
		}
		
	}
	
	public void updateTown(TownCard town){
		try{
		PreparedStatement query = connection.prepareStatment("update town_card set name_town=?, id_region=?"+"where name_town=?");
		query.setString(1, town.getTownName());
		query.setInt(1, 1);
		query.setString(3, town.getTownName());
		query.executeUpdate();
		}
		catch (SQLException){
			e.printStackTrace();
			
		}
	
	}
	
	public List<TownCard> getAllData(){
		List<TownCard> town=new ArrayList<TownCard>();
		try{
			Statement stateQuery=connection.createStatement();
			ResultSet result=stateQuery.executeQuery("select town_card.name_town, region_card.name_region,town_card.id_region FROM town_card, region_card where town_card.id_region=region_card.id_region;");
		    while (result.next()){
				TownCard town=new TownCard();
				town.setTownName(result.getString("town_card.name_town"));
				town.setTownRegion(result.getInt("town_card.id_region"));
				town.setRegionName(result.getString("region_card.name_region"));
				
			}	
			
		}catch (SQLException e){
			e.printStackTrace();
			
		}
		
		return town;
	}
	
}