package com.naima.phonebase;
 
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import java.io.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.naima.fronface.User;
import com.naima.fronface.Regions;
import com.naima.dao.UserConnection;

public class Login extends HttpServlet{
	private static String url="jdbc:postgresql://127.0.0.1:5432/phoneDirectory";
	private static String superNav="/adminout.jsp";
	private static String userNav="/userout.jsp";
	private static String regEdit="/regWork.jsp";
	String username="";
	String password="";
	private static UserConnection dao; 
	User user;
	public Login() {
        super();
		 user =new User();
	}
	
 	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType ("text/html; charset=UTF-8");
		PrintWriter pw = response.getWriter ();
		request.setCharacterEncoding ("UTF-8");
		String forward="";
        String action = request.getParameter("action");
		String spravochnik = request.getParameter("spravochnik");
		switch (action){
        case "delete":
                pw.println("you case delete");
				break;
        case "editRegion":
            forward = "/base/region/edit.jsp";
            String val = request.getParameter("valueId");
			Regions reg1 = dao.getRegionByID(val);
			request.setAttribute("region", reg1);
			break;
		 case "editRegionOK":
            forward = "";
            String val = request.getParameter("valueId");
			Regions reg1 = dao.getRegionByID(val);
			request.setAttribute("region", reg1);
			break;	
        case "listRegion":
            forward = "/base/regedit.jsp";
			request.setAttribute("regions", dao.selRegions());//
		    
			break;
	    case "listTown":
		    forward = "/base/regedit.jsp";//
			request.setAttribute("towns", dao.selTowns());//
			break;
			
		case "listStreet":
		    forward = "/base/regedit.jsp";//
			request.setAttribute("street", dao.selStreets());//
			break;	
		case "listParam":
		    forward = "/base/regedit.jsp";//
			request.setAttribute("marker", dao.selParams());//
			break;	
		case "listUsers":
		    forward = "/base/regedit.jsp";//
			request.setAttribute("phuser", dao.selClients());//
			break;	
				
	    default:
            pw.println("you case update");
        
		}
        RequestDispatcher view = request.getRequestDispatcher(forward);
        view.forward(request, response);
  	 
 
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          
		   username=request.getParameter("usname");
		   password=request.getParameter("pass"); 		   
		   
			boolean superUser;
			user.setUserName(username);
            user.setPassword(password);
			try {
			dao = new UserConnection(username, password);}
			catch(Exception e){
				PrintWriter out =response.getWriter();
            out.println("Ошибка подключения");		
				
			} 
            if (dao!=null){
				superUser=dao.checkUser();
				if(superUser){
					
					RequestDispatcher dispetch = request.getRequestDispatcher(superNav);
                    dispetch.forward(request, response);					
				}	
				else
				{
					RequestDispatcher dispetch = request.getRequestDispatcher(userNav);
                    dispetch.forward(request, response);		
				}		
			   
				
			}			
		  }
		 
		  
		  
		  
	
}


