package com.naima.controller;//

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.naima.dao.UserDao;
import com.naima.model.TownCard;

public class UserController extends HttpServlet {
	
	
	private static String INSERT_OR_EDIT="/user.jsp";
	private static String LIST_USER="/listuser.jsp";
	private UserDao dao;
	public UserController(){
		super();
		dao=new UserDao();
		
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String forward="";
		String action=request.getParameter("action");
		if(action.equalsIgnoreCase("delete")){
			String townName=request.getParameter("town_name");
			dao.deleteTown(townName);
			forward=LIST_USER;
			
		}
		
	}
	
	
	
}
