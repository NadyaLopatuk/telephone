package com.naima.model;
import java.util.Date;
public class User{
	String uname, password, 
	
	
}